# ساخت APK در GitHub

1. به https://github.com/new بروید و یک Repository جدید بسازید.
2. این ZIP را باز کنید و همه فایل‌ها و پوشه‌ها را در Repository قرار دهید.
3. در GitHub به بخش Actions بروید.
4. Workflow با نام Build BodyCropper APK را انتخاب کنید.
5. روی Run workflow بزنید.
6. پس از پایان، در بخش Artifacts فایل BodyCropper-debug را دریافت کنید.

برای ساخت Release:
یک Tag با نامی مثل v2.0.0 بسازید؛ Workflow علاوه بر APK، یک GitHub Release نیز ایجاد می‌کند.

این نسخه عمداً به gradle-wrapper.jar نیاز ندارد؛ GitHub Actions خودش Gradle 8.11.1 را نصب می‌کند.
