package ir.bodycropper.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import ir.bodycropper.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val selectedUris = mutableListOf<Uri>()

    private val pickImages = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selectedUris.clear()
        selectedUris.addAll(uris)
        binding.txtSelected.text = "${uris.size} عکس انتخاب شد."
    }

    private val pickZip = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedUris.clear()
            selectedUris.add(uri)
            binding.txtSelected.text = "فایل ZIP انتخاب شد."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnImages.setOnClickListener {
            pickImages.launch(arrayOf("image/*"))
        }
        binding.btnZip.setOnClickListener {
            pickZip.launch(arrayOf("application/zip", "application/octet-stream"))
        }
        binding.qualitySlider.addOnChangeListener { _, value, _ ->
            binding.txtQuality.text = "کیفیت JPG: ${value.roundToInt()}"
        }
        binding.btnStart.setOnClickListener {
            if (selectedUris.isEmpty()) {
                binding.txtStatus.text = "ابتدا عکس یا ZIP را انتخاب کنید."
            } else {
                startProcessing()
            }
        }
    }

    private fun startProcessing() {
        binding.progress.visibility = View.VISIBLE
        binding.btnStart.isEnabled = false
        binding.btnImages.isEnabled = false
        binding.btnZip.isEnabled = false
        binding.txtStatus.text = "آماده‌سازی..."

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val marginMm = binding.edtMargin.text?.toString()?.toFloatOrNull()?.coerceIn(0f, 50f) ?: 5f
                val maxOutput = binding.edtMaxSize.text?.toString()?.toIntOrNull()?.coerceAtLeast(0) ?: 0
                val quality = binding.qualitySlider.value.roundToInt()
                val png = binding.rbPng.isChecked
                val fast = binding.switchFast.isChecked
                val marginAt300Dpi = (marginMm * 300f / 25.4f).roundToInt()

                val imageFiles = collectInputImages()
                if (imageFiles.isEmpty()) error("هیچ تصویر قابل پردازشی در ورودی پیدا نشد.")

                val outputName = "BodyCropper_${System.currentTimeMillis()}.zip"
                val outputStream = openOutputStreamForDownload(outputName)

                val options = SubjectSegmenterOptions.Builder()
                    .enableMultipleSubjects(
                        SubjectSegmenterOptions.SubjectResultOptions.Builder()
                            .enableSubjectBitmap()
                            .build()
                    )
                    .build()

                val segmenter = SubjectSegmentation.getClient(options)
                var total = 0

                ZipOutputStream(outputStream).use { zos ->
                    imageFiles.forEachIndexed { index, file ->
                        val original = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                            ?: return@forEachIndexed

                        val source = if (fast) scaleDown(original, 2500) else original
                        if (source !== original) original.recycle()

                        val result = Tasks.await(
                            segmenter.process(InputImage.fromBitmap(source, 0))
                        )

                        result.subjects.forEachIndexed { personIndex, subject ->
                            val trimmed = trimTransparent(subject.bitmap)
                            val withMargin = addMargin(trimmed, marginAt300Dpi, png)
                            val finalBitmap = if (maxOutput > 0) scaleDown(withMargin, maxOutput) else withMargin

                            val ext = if (png) "png" else "jpg"
                            val entryName =
                                "${safeName(file.nameWithoutExtension)}_person_${(personIndex + 1).toString().padStart(2, '0')}.$ext"

                            zos.putNextEntry(ZipEntry(entryName))
                            if (png) {
                                finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, zos)
                            } else {
                                finalBitmap.compress(Bitmap.CompressFormat.JPEG, quality, zos)
                            }
                            zos.closeEntry()

                            if (finalBitmap !== withMargin) finalBitmap.recycle()
                            if (withMargin !== trimmed) withMargin.recycle()
                            if (trimmed !== subject.bitmap) trimmed.recycle()
                            total++
                        }

                        source.recycle()
                        withContext(Dispatchers.Main) {
                            binding.txtStatus.text =
                                "تصویر ${index + 1} از ${imageFiles.size} — تعداد افراد: $total"
                        }
                    }
                }

                segmenter.close()

                withContext(Dispatchers.Main) {
                    binding.progress.visibility = View.GONE
                    binding.btnStart.isEnabled = true
                    binding.btnImages.isEnabled = true
                    binding.btnZip.isEnabled = true
                    binding.txtStatus.text =
                        "✓ تمام شد — $total برش\n$outputLocation/$outputName"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.progress.visibility = View.GONE
                    binding.btnStart.isEnabled = true
                    binding.btnImages.isEnabled = true
                    binding.btnZip.isEnabled = true
                    binding.txtStatus.text = "خطا: ${e.message ?: "خطای ناشناخته"}"
                }
            }
        }
    }

    private var outputLocation = "Download/BodyCropper"

    private fun trimTransparent(bitmap: Bitmap): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1

        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val alpha = Color.alpha(pixels[row + x])
                if (alpha > 12) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        if (maxX < minX || maxY < minY) return bitmap.copy(Bitmap.Config.ARGB_8888, false)

        return Bitmap.createBitmap(
            bitmap,
            minX,
            minY,
            maxX - minX + 1,
            maxY - minY + 1
        )
    }

    private fun addMargin(bitmap: Bitmap, margin: Int, transparent: Boolean): Bitmap {
        val m = margin.coerceAtMost(max(bitmap.width, bitmap.height) / 3)
        val out = Bitmap.createBitmap(
            bitmap.width + m * 2,
            bitmap.height + m * 2,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(out)
        if (!transparent) canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(bitmap, m.toFloat(), m.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG))
        return out
    }

    private fun scaleDown(bitmap: Bitmap, maxSide: Int): Bitmap {
        if (maxSide <= 0) return bitmap
        val largest = max(bitmap.width, bitmap.height)
        if (largest <= maxSide) return bitmap

        val ratio = maxSide.toFloat() / largest
        val nw = (bitmap.width * ratio).roundToInt().coerceAtLeast(1)
        val nh = (bitmap.height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, nw, nh, true)
    }

    private fun collectInputImages(): List<File> {
        val out = mutableListOf<File>()
        selectedUris.forEach { uri ->
            val name = displayName(uri) ?: "input"
            if (name.lowercase(Locale.ROOT).endsWith(".zip")) {
                val dir = File(cacheDir, "unzipped_${System.nanoTime()}")
                dir.mkdirs()
                contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(BufferedInputStream(input)).use { zis ->
                        while (true) {
                            val entry = zis.nextEntry ?: break
                            if (!entry.isDirectory && isImage(entry.name)) {
                                val target = File(dir, safeName(entry.name))
                                FileOutputStream(target).use { fos -> zis.copyTo(fos) }
                                out += target
                            }
                        }
                    }
                }
            } else {
                val target = File.createTempFile("img_", ".jpg", cacheDir)
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                }
                out += target
            }
        }
        return out
    }

    private fun openOutputStreamForDownload(fileName: String): OutputStream {
        return if (android.os.Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BodyCropper")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("امکان ساخت فایل خروجی وجود ندارد")
            val raw = contentResolver.openOutputStream(uri)
                ?: error("امکان نوشتن فایل خروجی وجود ندارد")

            object : java.io.FilterOutputStream(raw) {
                override fun close() {
                    super.close()
                    val done = ContentValues().apply {
                        put(MediaStore.Downloads.IS_PENDING, 0)
                    }
                    contentResolver.update(uri, done, null, null)
                }
            }
        } else {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "BodyCropper")
            dir.mkdirs()
            FileOutputStream(File(dir, fileName))
        }
    }

    private fun isImage(name: String): Boolean {
        val n = name.lowercase(Locale.ROOT)
        return n.endsWith(".jpg") || n.endsWith(".jpeg") ||
                n.endsWith(".png") || n.endsWith(".webp") || n.endsWith(".bmp")
    }

    private fun safeName(name: String): String =
        name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun displayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return uri.lastPathSegment
    }
}
